<?php
chdir(__DIR__);
sleep(8);
unlink('yahoo-sh-19990529.lock');
?>